var express = require('express');
var InvoicesRouter = express.Router();
var InvoicesController = require('../Controller/invoices.controller') 

InvoicesRouter.get('/', InvoicesController.getAllInvoices);

InvoicesRouter.get('/status/:status',InvoicesController.getInvoicesByStatus);

InvoicesRouter.post('/', InvoicesController.createData);

module.exports = InvoicesRouter;