var express = require('express');
var CustomersRouter = express.Router();
var CustomerController = require('../Controller/customers.controller')


CustomersRouter.get('/:customerSlug/projects',CustomerController.getCustomersProjects);

CustomersRouter.get('/:customerSlug/invoices',CustomerController.getCustomersInvoices);

CustomersRouter.get('/', CustomerController.getAllCustomer);

CustomersRouter.get('/:customerSlug',CustomerController.getCustomerBySlug);

CustomersRouter.post('/', CustomerController.createData);



module.exports = CustomersRouter;