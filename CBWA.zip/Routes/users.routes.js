var express = require('express');
var UserRouter = express.Router();

const UserController = require('../Controller/users.controller');

UserRouter.get('/', UserController.getAllUser);

UserRouter.post('/', UserController.createData);

UserRouter.get('/:userEmail/projects',UserController.getUsersProjects);

UserRouter.get('/:userEmail',UserController.getUserByEmail);

module.exports = UserRouter;