var express = require('express');
var ProjectsRouter = express.Router();
var ProjectsController = require('../Controller/projects.controller')

ProjectsRouter.get('/', ProjectsController.getAllProjects);

ProjectsRouter.get('/status/:projectStatus',ProjectsController.getProjectsByStatus);

ProjectsRouter.post('/', ProjectsController.createData);

module.exports = ProjectsRouter;