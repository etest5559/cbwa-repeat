const config = require("config");
var MongoClient = require('mongodb').MongoClient;

exports.get = (collectionName, query = {}) => {
    return new Promise((resolve, reject) => {
      MongoClient.connect(config.get("uri"), {useNewUrlParser: true, useUnifiedTopology: true},(err, client) => {
        if (err) {
          console.log(err)
          return reject("=== get::MongoClient.connect")
        }
        const db = client.db('cbwa');
        const collection = db.collection(collectionName);
        console.log("query",query,collectionName)
        collection.find(query).toArray((err, docs) => {
          if (err) {
            console.log("  === get::collection.find")
            console.log(err)
            return reject(err)
          }

          resolve(docs);
          client.close();
        });
      });
    });
  };

  exports.create = (collectionName, query = {}) => {
    return new Promise((resolve, reject) => {
      MongoClient.connect(config.get("uri"), {useNewUrlParser: true, useUnifiedTopology: true},(err, client) => {
        if (err) {
          console.log(err)
          return reject("=== get::MongoClient.connect")
        }
        const db = client.db('cbwa');
        const collection = db.collection(collectionName);

        collection.insertOne(query).then((err, docs) => {
          if (err) {
            console.log("  === Create::collection.insertOne")
            console.log(err)
            return reject(err)
          }

          resolve(docs);
          client.close();
        });
      });
    });
  };