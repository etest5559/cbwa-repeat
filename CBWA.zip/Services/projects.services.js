var db = require('../db');

exports.getAllProjects = async () => {
    console.log("   inside Projects model");
      try {
        const projects = await db.get('projects');
        console.log(projects)
        return { projectsList: projects };
      } catch (ex) {
        console.log("PROJECTS GET ERROR")
        return { error: ex }
      }
};

exports.getProjectsByStatus = async (status = null) => {
    console.log("inside Projects model");
    if (!status) {
        return { error: 'status not found' }
    }

    try{
      const projects = await db.get('projects', { status });
      return { projectsList: projects };
    } catch (ex) {
      console.log("PROJECTS GET ERROR")
      return { error: ex }
    }
};

exports.create = async (data = null) => {
    console.log("inside Create model");
    if (!data) {
        return { error: 'data not found' }
    }

    try{
        const project = await db.create('projects',data);
        if(project){
          return {projectData: project}
        } else {
          return { error: "Project created failed"}
        }
        
      } catch (ex) {
        return { error: ex }
      }
}