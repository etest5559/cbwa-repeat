var db = require('../db');

exports.getAllCustomers = async () => {
    console.log("   inside Customers model");
      try {
        const customers = await db.get('customers');
        console.log(customers)
        return { customersList: customers };
      } catch (ex) {
        console.log("CUSTOMERS GET ERROR")
        return { error: ex }
      }
};

exports.getCustomersBySlug = async (slug) => {
    console.log("inside Customers model");
    if (!slug) {
        return { error: 'Slug​ not found' }
    }

    try{
      const customers = await db.get('customers', {slug});
      return { customersList: customers };
    } catch (ex) {
      return { error: ex }
    }
};

exports.getCustomersProjects = async (slugParms = null) => {
    console.log("inside Customers model");
    if (!slugParms) {
        return { error: 'Slug​ not found' }
    }

    try{
      const customer = await db.get('customers', {slug:slugParms});
      if(customer){
        const project = await db.get('projects', { customerId: ""+customer[0]._id});
        return {customersProjectsList: project}
      } else {
        return { error: "Customer not found by Email"}
      }
      
    } catch (ex) {
      return { error: ex }
    }
};

exports.getCustomersInvoices = async (parms = null) => {
    console.log("inside Customers model");
    if (!parms) {
        return { error: 'Slug​ not found' }
    }

    try{
      const customer = await db.get('customers', {slug:parms});
      if(customer){
        const project = await db.get('invoices', { customerId: ""+customer[0]._id});
        return {customerInvoicesList: project}
      } else {
        return { error: "Customer not found by Email"}
      }
      
    } catch (ex) {
      return { error: ex }
    }
};

exports.create = async (data = null) => {
    console.log("inside Create model");
    if (!data) {
        return { error: 'data not found' }
    }

    try{
        const customer = await db.create('customers',data);
        if(customer){
          return {customerData: customer}
        } else {
          return { error: "Customer created failed"}
        }
        
      } catch (ex) {
        return { error: ex }
      }
}