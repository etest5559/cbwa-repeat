var db = require('../db');

exports.getAllInvoices = async () => {
    console.log("   inside Invoices model");
      try {
        const invoices = await db.get('invoices');
        console.log(invoices)
        return { invoicesList: invoices };
      } catch (ex) {
        console.log("INVOICES GET ERROR")
        return { error: ex }
      }
};

exports.getInvoicesByStatus = async (status = null) => {
    console.log("inside Invoices model");
    if (!status) {
        return { error: 'status not found' }
    }

    try{
      const invoices = await db.get('invoices', { status });
      return { invoicesList: invoices };
    } catch (ex) {
      console.log("INVOICES GET ERROR")
      return { error: ex }
    }
};

exports.create = async (data = null) => {
    console.log("inside Create model");
    if (!data) {
        return { error: 'data not found' }
    }

    try{
        const invoice = await db.create('invoices',data);
        if(invoice){
          return {invoiceData: invoice}
        } else {
          return { error: "Invoice created failed"}
        }
        
      } catch (ex) {
        return { error: ex }
      }
}