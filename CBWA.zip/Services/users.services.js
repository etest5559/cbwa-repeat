var db = require('../db');

exports.getAllUsers = async () => {
    console.log("   inside User model");
      try {
        const users = await db.get('users');
        console.log(users)
        return { usersList: users };
      } catch (ex) {
        console.log("USER GET ERROR")
        return { error: ex }
      }
};

exports.getOneByEmail = async (email = null) => {
    console.log("inside User model");
    if (!email) {
        return { error: 'Email not found' }
    }

    try{
      const user = await db.get('users', { email });
      return { User: user };
    } catch (ex) {
      return { error: ex }
    }
};

exports.getUserProjects = async (email = null) => {
    console.log("inside User model");
    if (!email) {
        return { error: 'Email not found' }
    }

    try{
      const user = await db.get('users', { email });
      if(user){
          console.log("fddgf",user);
        const project = await db.get('projects', { userId: ""+user[0]._id});
        console.log("dsfsgf",project)
        return {userProjectsList: project}
      } else {
        return { error: "User not found by Email"}
      }
      
    } catch (ex) {
      return { error: ex }
    }
};


exports.create = async (data = null) => {
    console.log("inside Create model");
    if (!data) {
        return { error: 'data not found' }
    }

    try{
        const user = await db.create('users',data);
        if(user){
          return {userData: user}
        } else {
          return { error: "User created failed"}
        }
        
      } catch (ex) {
        return { error: ex }
      }
}