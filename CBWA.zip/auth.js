const config = require("config");

exports.verify = async (req,res,next) => {
    
    const apikey = req.headers['x-api-key'];
    if(!apikey){
        res.status(403).json( {message:"Please Provide Api key"})
    }else{
        if(config.get("myKey")== apikey){
            next();
        } else {
            res.status(403).json( {message:"Please Provide a valid Api key"})
        }
    } 
    
}