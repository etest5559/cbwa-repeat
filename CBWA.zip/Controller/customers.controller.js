var customer = require('../Services/customers.services')

exports.getAllCustomer = async (req,res)=>{
    
    const {customersList, error} = await customer.getAllCustomers()
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ customers: customersList });
};

exports.getCustomerBySlug = async (req,res)=>{
    var {customerSlug} = req.params
    const {customersList, error} = await customer.getCustomersBySlug(customerSlug);
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ customers: customersList });
};

exports.getCustomersProjects = async (req,res)=>{
    var {customerSlug} = req.params;
    const {customersProjectsList, error} = await customer.getCustomersProjects(customerSlug);
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ customersProjects: customersProjectsList });
 };

 exports.getCustomersInvoices = async (req,res)=>{
    var {customerSlug} = req.params;
    const {customerInvoicesList, error} = await customer.getCustomersInvoices(customerSlug);
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ customerInvoices: customerInvoicesList });
 };

 exports.createData = async (req,res)=>{
    
    const {customerData, error} = await customer.create(req.body)
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ customerData: customerData });
 };