var users = require('../Services/users.services')

exports.getAllUser = async (req,res)=>{
    
    const {usersList, error} = await users.getAllUsers()
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ users: usersList });
};

exports.getUserByEmail = async (req,res)=>{
    const {userEmail} = req.params;
    const {User, error} = await users.getOneByEmail(userEmail)
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ users: User });
};

exports.getUsersProjects = async (req,res)=>{
    const {userEmail} = req.params
    const {userProjectsList, error} = await users.getUserProjects(userEmail)
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ userProjects: userProjectsList });
 };

 exports.createData = async (req,res)=>{
    
    const {userData, error} = await users.create(req.body)
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ userData: userData });
 };