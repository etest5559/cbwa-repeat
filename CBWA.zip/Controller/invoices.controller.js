var invoices = require('../Services/invoices.services')

exports.getAllInvoices = async (req,res)=>{
    
    const {invoicesList, error} = await invoices.getAllInvoices()
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ invoices: invoicesList });
};

exports.getInvoicesByStatus = async (req,res)=>{
    const {status} = req.params
    const {invoicesList, error} = await invoices.getInvoicesByStatus(status)
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ invoices: invoicesList });
};

exports.createData = async (req,res)=>{
    
    const {invoiceData, error} = await invoices.create(req.body)
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ invoiceData: invoiceData });
 };