var projects = require('../Services/projects.services')

exports.getAllProjects = async (req,res)=>{
    
    const {projectsList, error} = await projects.getAllProjects()
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ projects: projectsList });
};

exports.getProjectsByStatus = async (req,res)=>{
    const {projectStatus} = req.params
    const {projectsList, error} = await projects.getProjectsByStatus(projectStatus)
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ projects: projectsList });
};

exports.createData = async (req,res)=>{
    
    const {projectData, error} = await projects.create(req.body)
    if (error) {
      return res.status(500).json( {error})
    }
    res.json({ projectData: projectData });
 };

